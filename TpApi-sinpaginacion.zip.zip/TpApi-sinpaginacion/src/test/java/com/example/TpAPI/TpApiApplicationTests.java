package com.example.TpAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
