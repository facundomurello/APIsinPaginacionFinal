package com.example.TpAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpApiApplication.class, args);
	}

}
