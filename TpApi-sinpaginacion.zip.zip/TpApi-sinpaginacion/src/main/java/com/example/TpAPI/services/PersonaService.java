package com.example.TpAPI.services;

import com.example.TpAPI.entities.Persona;

public interface PersonaService extends BaseService<Persona, Long>{
}
