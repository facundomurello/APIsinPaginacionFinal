package com.example.TpAPI.services;

import com.example.TpAPI.entities.Localidad;

public interface LocalidadService extends BaseService<Localidad, Long>{
}
