package com.example.TpAPI.services;

import com.example.TpAPI.entities.Autor;

public interface AutorService extends BaseService<Autor, Long>{
}
